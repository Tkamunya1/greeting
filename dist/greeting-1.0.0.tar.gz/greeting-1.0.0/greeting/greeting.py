def say_hello(name):
    """Prints a greeting message."""
    print(f"Hello, {name}!")

def say_goodbye(name):
    """Prints a goodbye message."""
    print(f"Goodbye, {name}!")
