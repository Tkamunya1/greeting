from setuptools import setup

setup(
    name='greeting',
    version='1.0.0',
    packages=['greeting'],
    description='A simple package for greetings',
    author='Titus K',
    author_email='tituskamunya@gmail.com',
    url='https://github.com/Tkamunya1/greeting',
)
